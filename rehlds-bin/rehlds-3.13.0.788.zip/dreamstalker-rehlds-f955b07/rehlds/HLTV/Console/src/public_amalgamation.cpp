#include "precompiled.h"

#include "interface.cpp"
#include "stdc++compat.cpp"
