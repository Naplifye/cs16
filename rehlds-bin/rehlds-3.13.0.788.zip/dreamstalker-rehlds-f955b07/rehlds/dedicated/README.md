## HLDS Launcher <img align="right" src="https://cloud.githubusercontent.com/assets/5860435/25316344/add057d4-288f-11e7-93ab-84706a388c3c.png" alt="HLDS Launcher"/>

## What is this?
Dedicated Server Launcher for Goldsrc based games
