#include "precompiled.h"

void _LogFunctionTrace(const char *pFunctionName, const char *param)
{
	//{
	//	char *entry;
	//}
}

double _StartFunctionTimer()
{
	//CCounter::GetCurTime();
	return 0;
}

void _LogFunctionTraceMaxTime(const char *pFunctionName, double startTime, double maxTime)
{
	//{
	//	double timeDiff;
	//	CCounter::GetCurTime();
	//	_LogFunctionTrace(const char *pFunctionName, const char *param);
	//}
}

void ClearErrorLogs()
{
}

void Error(const char *pMsg, ...)
{
	//{
	//	char logName;
	//	FILE *f;
	//	va_list args;
	//	{
	//		int i;
	//	}
	//}
}
